const $=id=>document.getElementById(id);
let users=JSON.parse(localStorage.getItem("toklite_users")||"{}");
let posts=JSON.parse(localStorage.getItem("toklite_posts")||"[]");
let current=localStorage.getItem("toklite_current");
let loginMode=false;

function save(){localStorage.setItem("toklite_users",JSON.stringify(users));localStorage.setItem("toklite_posts",JSON.stringify(posts));}
function showApp(){ $("auth").hidden=!!current; $("app").hidden=!current; if(current){renderFeed();renderProfile();}}
function renderFeed(){
  const feed=$("feed"); feed.innerHTML="";
  if(!posts.length){feed.innerHTML='<div class="empty">No videos yet. Be the first to post! 🎬</div>';return}
  [...posts].reverse().forEach((p,i)=>{
    const el=document.createElement("article"); el.className="card post";
    el.innerHTML=`<video controls playsinline src="${p.video}"></video>
      <div class="meta"><div class="user">@${escapeHtml(p.user)}</div>
      <p>${escapeHtml(p.caption||"")}</p><small>${new Date(p.date).toLocaleString()}</small>
      <div class="actions"><button class="like ${p.likes.includes(current)?"liked":""}">${p.likes.includes(current)?"♥":"♡"} ${p.likes.length}</button></div></div>`;
    el.querySelector(".like").onclick=()=>{const real=posts.find(x=>x.id===p.id); const n=real.likes.indexOf(current); n<0?real.likes.push(current):real.likes.splice(n,1);save();renderFeed()};
    feed.appendChild(el);
  });
}
function renderProfile(){$("profileName").textContent="@"+current;$("postCount").textContent=posts.filter(p=>p.user===current).length+" posts";}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

$("authAction").onclick=()=>{
 const u=$("username").value.trim().toLowerCase(),pw=$("password").value;
 if(!/^[a-z0-9_]{3,20}$/.test(u)) return $("authMsg").textContent="Use 3–20 letters, numbers, or underscores.";
 if(pw.length<4) return $("authMsg").textContent="Password must be at least 4 characters.";
 if(loginMode){if(!users[u]||users[u]!==pw)return $("authMsg").textContent="Wrong username or password."}
 else {if(users[u])return $("authMsg").textContent="That username already exists.";users[u]=pw;save();}
 current=u;localStorage.setItem("toklite_current",current);showApp();
};
$("switchAuth").onclick=()=>{loginMode=!loginMode;$("authTitle").textContent=loginMode?"Log in":"Create your account";$("authAction").textContent=loginMode?"Log in":"Create account";$("switchAuth").textContent=loginMode?"Need an account? Create one":"Already have an account? Log in";$("authMsg").textContent=""};
$("postBtn").onclick=()=>{
 if(!current)return;
 const f=$("videoFile").files[0]; if(!f)return $("postMsg").textContent="Choose a video first.";
 if(f.size>20*1024*1024)return $("postMsg").textContent="Demo limit: 20 MB.";
 const r=new FileReader();r.onload=()=>{posts.push({id:Date.now(),user:current,caption:$("caption").value,video:r.result,date:Date.now(),likes:[]});save();$("caption").value="";$("videoFile").value="";$("postMsg").textContent="Posted!";renderFeed();renderProfile();};r.readAsDataURL(f);
};
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.querySelectorAll(".view").forEach(x=>x.hidden=true);$(b.dataset.tab).hidden=false;if(b.dataset.tab==="profile")renderProfile()});
$("accountBtn").onclick=()=>{current=null;localStorage.removeItem("toklite_current");loginMode=false;$("authTitle").textContent="Create your account";$("authAction").textContent="Create account";showApp()};
$("logout").onclick=()=>{current=null;localStorage.removeItem("toklite_current");showApp()};
showApp();